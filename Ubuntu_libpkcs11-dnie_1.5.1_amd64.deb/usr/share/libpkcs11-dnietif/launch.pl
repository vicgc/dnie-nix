#!/usr/bin/perl


system("killall firefox");

#if (-e "/usr/bin/firefox") {
#  system("/usr/bin/firefox /usr/share/libpkcs11-dnietif/launch.html &");
#} elsif (-e "/usr/local/bin/firefox") {
#  system("/usr/local/bin/firefox /usr/share/libpkcs11-dnietif/launch.html &");
#}
system("firefox /usr/share/libpkcs11-dnietif/launch.html &");

exit(0);
